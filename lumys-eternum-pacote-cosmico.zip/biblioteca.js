<!-- Arquivo: biblioteca.js - Conteúdo de exemplo -->
