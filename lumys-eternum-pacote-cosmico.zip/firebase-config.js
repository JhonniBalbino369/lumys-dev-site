<!-- Arquivo: firebase-config.js - Conteúdo de exemplo -->
