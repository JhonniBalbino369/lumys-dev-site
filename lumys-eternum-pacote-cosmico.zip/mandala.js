<!-- Arquivo: mandala.js - Conteúdo de exemplo -->
