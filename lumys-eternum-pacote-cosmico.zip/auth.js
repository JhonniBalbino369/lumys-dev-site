<!-- Arquivo: auth.js - Conteúdo de exemplo -->
